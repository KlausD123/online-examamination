const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const md = fs.readFileSync(path.join(__dirname, 'design_document.md'), 'utf8');
const diagDir = path.join(__dirname, 'diagrams');
if (!fs.existsSync(diagDir)) fs.mkdirSync(diagDir);

// Extract all mermaid code blocks
const regex = /```mermaid\n([\s\S]*?)```/g;
let match;
const blocks = [];
while ((match = regex.exec(md)) !== null) {
  blocks.push(match[1].trim());
}

const names = [
  '01_class_diagram',
  '02_sequence_login',
  '03_sequence_exam_submission',
  '04_sequence_viva_lifecycle',
  '05_sequence_course_join',
  '06_activity_autograding',
  '07_activity_registration',
  '08_activity_viva_flow',
  '09_activity_password_reset',
  '10_activity_course_creation',
  '11_state_exam_lifecycle',
  '12_state_submission',
  '13_state_viva_session',
  '14_state_notification',
  '15_component_frontend',
  '16_component_state_mgmt',
  '17_sequence_fullstack_flow',
];

console.log(`Found ${blocks.length} Mermaid blocks, expecting ${names.length}`);

blocks.forEach((code, i) => {
  const name = names[i] || `diagram_${i+1}`;
  const mmdFile = path.join(diagDir, name + '.mmd');
  const pngFile = path.join(diagDir, name + '.png');
  
  fs.writeFileSync(mmdFile, code);
  console.log(`Converting ${name}...`);
  
  try {
    execSync(`mmdc -i "${mmdFile}" -o "${pngFile}" -w 2000 -H 1500 -b white`, {
      timeout: 30000,
      stdio: 'pipe'
    });
    console.log(`  ✅ ${name}.png saved`);
  } catch (e) {
    console.log(`  ❌ ${name} failed: ${e.message.substring(0, 100)}`);
  }
});

console.log('\nDone! Check the diagrams/ folder.');
