const fs = require('fs');
const path = require('path');

const guiTestsDir = path.join(__dirname, 'gui_tests');
if (!fs.existsSync(guiTestsDir)) {
  fs.mkdirSync(guiTestsDir);
}

const loginTest = `describe('GUI Testing: Login & Authentication', () => {
  it('should successfully log in a user with valid credentials', () => {
    cy.visit('/login');
    cy.get('input[name="email"]').type('student@example.com');
    cy.get('input[name="password"]').type('password123');
    cy.get('button[type="submit"]').click();
    cy.url().should('include', '/dashboard');
    cy.get('.welcome-message').should('contain', 'Welcome');
  });

  it('should show error message on invalid credentials', () => {
    cy.visit('/login');
    cy.get('input[name="email"]').type('wrong@example.com');
    cy.get('input[name="password"]').type('badpass');
    cy.get('button[type="submit"]').click();
    cy.get('.error-toast').should('be.visible').and('contain', 'Invalid credentials');
  });
});`;

const examTest = `describe('GUI Testing: Exam Taking Process', () => {
  it('should allow student to start and submit an exam', () => {
    cy.visit('/dashboard');
    cy.get('.exam-card').first().click();
    cy.get('button.start-exam').click();
    
    // Accept camera permissions mock
    cy.window().then(win => {
      cy.stub(win.navigator.mediaDevices, 'getUserMedia').resolves({});
    });

    cy.get('.question-container').should('be.visible');
    cy.get('input[type="radio"]').first().click();
    cy.get('button.next-question').click();
    cy.get('button.submit-exam').click();
    cy.get('.success-modal').should('contain', 'Exam submitted successfully');
  });
});`;

const adminTest = `describe('GUI Testing: Admin Dashboard', () => {
  it('should allow admin to create a new exam', () => {
    cy.visit('/admin/exams/new');
    cy.get('input[name="title"]').type('Midterm Mathematics');
    cy.get('input[name="duration"]').type('60');
    cy.get('button.add-question').click();
    cy.get('input[name="questionText"]').type('What is 2+2?');
    cy.get('button.save-exam').click();
    cy.get('.table-row').should('contain', 'Midterm Mathematics');
  });
});`;

fs.writeFileSync(path.join(guiTestsDir, 'auth_gui.spec.js'), loginTest);
fs.writeFileSync(path.join(guiTestsDir, 'exam_gui.spec.js'), examTest);
fs.writeFileSync(path.join(guiTestsDir, 'admin_gui.spec.js'), adminTest);

console.log('GUI Test Scripts generated successfully!');
