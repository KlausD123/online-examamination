# Design Document — DExam AI Examination Platform

## Table of Contents
1. [Class Diagram](#1-class-diagram)
2. [Sequence Diagrams](#2-sequence-diagrams)
3. [Activity Diagrams](#3-activity-diagrams)
4. [State Diagrams](#4-state-diagrams)

---

## 1. Class Diagram

The class diagram represents all database entities (tables), their attributes, and the relationships between them as defined in `database.sql`.

```mermaid
classDiagram
    class User {
        +int user_id PK
        +string name
        +string email
        +string password
        +enum role [admin, student]
        +text avatar_url
        +text bio
        +timestamp created_at
        +login()
        +register()
        +changePassword()
        +forgotPassword()
    }

    class Student {
        +int student_id PK
        +int user_id FK
        +string department
        +string year
    }

    class Exam {
        +int exam_id PK
        +string title
        +text description
        +int duration_minutes
        +int total_marks
        +enum status [draft, published, archived]
        +datetime scheduled_at
        +datetime end_at
        +int created_by FK
        +int course_id FK
        +enum exam_type [global, course_global, targeted]
        +create()
        +publish()
        +archive()
        +exportCSV()
    }

    class Question {
        +int question_id PK
        +int exam_id FK
        +text question_text
        +enum question_type [MCQ, TRUE_FALSE, SHORT_ANSWER, DESCRIPTIVE]
        +enum difficulty [Easy, Medium, Hard]
        +int marks
        +string correct_answer
        +text explanation
        +int question_order
    }

    class Option {
        +int option_id PK
        +int question_id FK
        +text text
        +int option_order
    }

    class Submission {
        +int submission_id PK
        +int exam_id FK
        +int student_id FK
        +enum status [in_progress, submitted, cheated]
        +datetime start_time
        +datetime submit_time
        +start()
        +submit()
    }

    class Answer {
        +int answer_id PK
        +int submission_id FK
        +int question_id FK
        +text answer_text
    }

    class Result {
        +int result_id PK
        +int submission_id FK
        +decimal total_score
        +string grade
        +boolean cheating_detected
        +timestamp created_at
        +autoGrade()
    }

    class Course {
        +int course_id PK
        +string name
        +text description
        +string join_code
        +enum course_type [global, private]
        +int created_by FK
        +timestamp created_at
        +generateJoinCode()
    }

    class CourseMember {
        +int member_id PK
        +int course_id FK
        +int student_id FK
        +timestamp joined_at
    }

    class ExamAssignment {
        +int id PK
        +int exam_id FK
        +int student_id FK
        +timestamp assigned_at
    }

    class Notification {
        +int notification_id PK
        +string title
        +text message
        +enum type [info, warning, urgent, success]
        +int admin_id FK
        +int recipient_id FK
        +string viva_room_id
        +datetime expires_at
        +timestamp created_at
    }

    class VivaSession {
        +string viva_id PK
        +string title
        +string topic
        +json questions
        +int questions_count
        +int created_by FK
        +string status
        +datetime ended_at
        +timestamp created_at
        +createSession()
        +endSession()
        +lockSession()
    }

    class VivaResult {
        +int result_id PK
        +string viva_id FK
        +int student_id FK
        +string student_name
        +decimal total_score
        +string grade
        +text full_transcript
        +json ai_report
        +int correct_count
        +int total_questions
        +boolean result_visible
        +timestamp created_at
    }

    User "1" -- "0..1" Student : extends
    User "1" -- "*" Exam : creates
    User "1" -- "*" Submission : takes
    User "1" -- "*" Course : creates
    User "1" -- "*" Notification : receives
    Exam "1" -- "*" Question : contains
    Question "1" -- "*" Option : has
    Exam "1" -- "*" Submission : receives
    Submission "1" -- "*" Answer : includes
    Submission "1" -- "0..1" Result : produces
    Answer "*" -- "1" Question : answers
    Course "1" -- "*" CourseMember : has
    User "1" -- "*" CourseMember : joins
    Exam "1" -- "*" ExamAssignment : targets
    User "1" -- "*" ExamAssignment : assigned
    User "1" -- "*" VivaSession : creates
    VivaSession "1" -- "*" VivaResult : generates
    VivaSession "1" -- "*" Notification : sends invites via viva_room_id
```

---

## 2. Sequence Diagrams

### 2.1 Student Login Sequence

```mermaid
sequenceDiagram
    actor Student
    participant Frontend as React Frontend
    participant Server as Express Server
    participant AuthMW as authenticateToken Middleware
    participant AuthRoute as /api/auth/login
    participant DB as MySQL Database

    Student->>Frontend: Enter email & password
    Frontend->>Server: POST /api/auth/login
    Server->>AuthRoute: Route handler
    AuthRoute->>DB: SELECT * FROM users WHERE email = ?
    DB-->>AuthRoute: User record
    AuthRoute->>AuthRoute: bcrypt.compare(password, hash)
    alt Password matches
        AuthRoute->>AuthRoute: jwt.sign(payload, secret, 24h)
        AuthRoute-->>Frontend: 200 {token, user}
        Frontend->>Frontend: Store JWT in localStorage
        Frontend-->>Student: Redirect to Dashboard
    else Password invalid
        AuthRoute-->>Frontend: 401 {error: "Invalid email or password"}
        Frontend-->>Student: Show error toast
    end
```

### 2.2 Exam Taking & Submission Sequence

```mermaid
sequenceDiagram
    actor Student
    participant Frontend as React Frontend
    participant AuthMW as Auth Middleware
    participant SubRoute as /api/submissions
    participant DB as MySQL Database

    Student->>Frontend: Click "Start Exam"
    Frontend->>AuthMW: POST /api/submissions/start (JWT)
    AuthMW->>AuthMW: Verify JWT token
    AuthMW->>SubRoute: req.user attached
    SubRoute->>DB: SELECT status FROM exams WHERE exam_id = ?
    DB-->>SubRoute: exam.status = 'published'
    SubRoute->>DB: SELECT * FROM submissions WHERE exam_id = ? AND student_id = ?
    DB-->>SubRoute: No existing submission
    SubRoute->>DB: INSERT INTO submissions (status = 'in_progress')
    DB-->>SubRoute: submission_id = 42
    SubRoute-->>Frontend: 201 {submission_id: 42}
    Frontend-->>Student: Show exam questions + timer

    Note over Student,Frontend: Student answers questions...

    Student->>Frontend: Click "Submit Exam"
    Frontend->>AuthMW: POST /api/submissions/submit (answers[])
    AuthMW->>SubRoute: req.user attached
    SubRoute->>DB: SELECT * FROM submissions WHERE submission_id = ?
    SubRoute->>SubRoute: Validate ownership & status
    SubRoute->>DB: UPDATE submissions SET status = 'submitted'
    loop For each answer
        SubRoute->>DB: INSERT INTO answers (question_id, answer_text)
        SubRoute->>DB: SELECT correct_answer FROM questions
        SubRoute->>SubRoute: Compare & accumulate score
    end
    SubRoute->>DB: SELECT total_marks FROM exams
    SubRoute->>SubRoute: Calculate grade (A/B/C/D/F)
    SubRoute->>DB: INSERT INTO results (total_score, grade)
    SubRoute-->>Frontend: 200 {message: "Exam submitted successfully"}
    Frontend-->>Student: Show success modal
```

### 2.3 Viva Session Lifecycle Sequence

```mermaid
sequenceDiagram
    actor Admin
    actor Student
    participant Frontend as React Frontend
    participant VivaRoute as /api/viva
    participant SocketIO as Socket.IO Server
    participant DB as MySQL Database
    participant Jitsi as Jitsi Meet

    Admin->>VivaRoute: POST /api/viva (title, topic, questions)
    VivaRoute->>DB: INSERT INTO viva_sessions
    VivaRoute-->>Admin: 201 {viva_id}

    Admin->>VivaRoute: POST /api/viva/invite (emails, vivaId)
    VivaRoute->>DB: SELECT user_id FROM users WHERE email = ?
    VivaRoute->>DB: INSERT INTO notifications (type: urgent)
    VivaRoute-->>Admin: {message: "Invited N students"}

    Student->>Frontend: Clicks notification link
    Frontend->>Frontend: Load Jitsi Meet iframe
    Admin->>Frontend: Load Jitsi Meet iframe
    Frontend->>Jitsi: Connect to Jitsi room

    Note over Admin,Student: Viva Q&A via Jitsi audio/video

    Admin->>SocketIO: emit("question-text", {text})
    SocketIO->>Student: emit("question-text", {text})
    Student->>SocketIO: emit("student-answer-final", {text})
    SocketIO->>Admin: emit("student-answer-final", {text})

    Admin->>VivaRoute: POST /api/viva/:id/result (scores, transcript)
    VivaRoute->>DB: INSERT INTO viva_results
    VivaRoute->>DB: INSERT INTO notifications ("Result Available")
    VivaRoute-->>Admin: 201 {message: "Result saved"}

    Admin->>VivaRoute: POST /api/viva/:id/end
    VivaRoute->>DB: UPDATE viva_sessions SET status = 'ended'
    VivaRoute->>DB: DELETE FROM notifications WHERE viva_room_id = ?
    VivaRoute->>DB: INSERT notification ("Session Ended") for each student
    VivaRoute-->>Admin: {message: "Session ended"}
```

### 2.4 Course Join Sequence

```mermaid
sequenceDiagram
    actor Student
    participant Frontend as React Frontend
    participant AuthMW as Auth Middleware
    participant CourseRoute as /api/courses
    participant DB as MySQL Database

    Student->>Frontend: Enter join code "MATH101"
    Frontend->>AuthMW: POST /api/courses/join (JWT)
    AuthMW->>CourseRoute: req.user attached
    CourseRoute->>DB: SELECT * FROM courses WHERE join_code = 'MATH101'
    alt Course found
        DB-->>CourseRoute: course record
        CourseRoute->>DB: INSERT IGNORE INTO course_members (course_id, student_id)
        CourseRoute-->>Frontend: 200 {course_id, name, join_code}
        Frontend-->>Student: Show "Joined successfully" toast
    else Invalid code
        DB-->>CourseRoute: empty result
        CourseRoute-->>Frontend: 404 {error: "Invalid join code"}
        Frontend-->>Student: Show error message
    end
```

---

## 3. Activity Diagrams

### 3.1 Exam Submission & Auto-Grading Activity

```mermaid
flowchart TD
    A([Student clicks Submit]) --> B{Submission exists?}
    B -- No --> C[Return 404 error]
    B -- Yes --> D{Is student the owner?}
    D -- No --> E[Return 403 Forbidden]
    D -- Yes --> F{Status = in_progress?}
    F -- No --> G[Return 400 Already submitted]
    F -- Yes --> H{Cheating detected?}
    H -- Yes --> I[Set status = cheated]
    I --> J[Insert result with cheating_detected = 1]
    H -- No --> K[Set status = submitted]
    K --> L{Answers provided?}
    L -- No --> M[Score = 0]
    L -- Yes --> N[Loop through each answer]
    N --> O[Save answer to DB]
    O --> P{Question type MCQ or TRUE_FALSE?}
    P -- Yes --> Q{Answer matches correct_answer?}
    Q -- Yes --> R[Add marks to totalScore]
    Q -- No --> S[Skip]
    P -- No --> S
    R --> T{More answers?}
    S --> T
    T -- Yes --> N
    T -- No --> M
    M --> U[Fetch exam total_marks]
    U --> V[Calculate percentage]
    V --> W{Score >= 90%?}
    W -- Yes --> X["Grade = A"]
    W -- No --> Y{Score >= 80%?}
    Y -- Yes --> Z["Grade = B"]
    Y -- No --> AA{Score >= 70%?}
    AA -- Yes --> AB["Grade = C"]
    AA -- No --> AC{Score >= 60%?}
    AC -- Yes --> AD["Grade = D"]
    AC -- No --> AE["Grade = F"]
    X --> AF[Insert into results table]
    Z --> AF
    AB --> AF
    AD --> AF
    AE --> AF
    J --> AF
    AF --> AG([Return success response])
```

### 3.2 User Registration Activity

```mermaid
flowchart TD
    A([User submits registration form]) --> B{Name, email, password provided?}
    B -- No --> C[Return 400 Missing fields]
    B -- Yes --> D[Query DB for existing email]
    D --> E{Email already exists?}
    E -- Yes --> F[Return 400 Email already exists]
    E -- No --> G[Hash password with bcrypt]
    G --> H[INSERT into users table with role = student]
    H --> I[INSERT into students table with department and year]
    I --> J([Return 201 Registration successful])
```

### 3.3 Viva Session Complete Activity

```mermaid
flowchart TD
    A([Admin creates Viva session]) --> B[Generate UUID for viva_id]
    B --> C[Store title, topic, questions in DB]
    C --> D{Invite students?}
    D -- Yes --> E[Loop through email list]
    E --> F{Student exists in DB?}
    F -- Yes --> G[Insert urgent notification with viva_room_id]
    F -- No --> H[Skip email]
    G --> I{More emails?}
    H --> I
    I -- Yes --> E
    I -- No --> J[Student receives notification]
    D -- No --> J
    J --> K[Student joins Jitsi room]
    K --> L[Admin asks questions via Jitsi audio]
    L --> M[Student answers via Jitsi audio]
    M --> N{More questions?}
    N -- Yes --> L
    N -- No --> O[Admin finalizes and grades]
    O --> P[Save viva_result with transcript and AI report]
    P --> Q[Send result notification to student]
    Q --> R{End session?}
    R -- Yes --> S[Update viva_sessions status = ended]
    S --> T[Delete all invitation notifications]
    T --> U[Send session ended notification to all invited students]
    U --> V([Session complete])
    R -- No --> L
```

### 3.4 Password Reset Activity

```mermaid
flowchart TD
    A([User clicks Forgot Password]) --> B{Email provided?}
    B -- No --> C[Return 400 error]
    B -- Yes --> D[Query DB for user]
    D --> E{User exists?}
    E -- No --> F["Return 200 generic message (security)"]
    E -- Yes --> G[Generate 6-digit OTP]
    G --> H[Store OTP in memory with 10-min expiry]
    H --> I[Send OTP email via SMTP/Nodemailer]
    I --> J([Return success message])
    J --> K([User enters OTP + new password])
    K --> L{OTP record exists?}
    L -- No --> M[Return 400 No code found]
    L -- Yes --> N{OTP expired?}
    N -- Yes --> O[Delete record, return 400]
    N -- No --> P{OTP matches?}
    P -- No --> Q[Return 400 Invalid code]
    P -- Yes --> R[Hash new password with bcrypt]
    R --> S[UPDATE users SET password]
    S --> T[Delete OTP record]
    T --> U([Return success - Password reset])
```
### 3.5 Course Creation Activity (Unique Join Code)

```mermaid
flowchart TD
    A([Admin submits Create Course]) --> B{Course name provided?}
    B -- No --> C[Return 400 error]
    B -- Yes --> D{course_type = global?}
    D -- Yes --> E["Set type = global"]
    D -- No --> F["Set type = private"]
    E --> G[Generate random 6-char code]
    F --> G
    G --> H[Query DB: SELECT FROM courses WHERE join_code = code]
    H --> I{Code already exists?}
    I -- Yes --> G
    I -- No --> J[INSERT INTO courses with unique join_code]
    J --> K{Type is global?}
    K -- Yes --> L["INSERT all existing students into course_members"]
    K -- No --> M[Skip auto-enroll]
    L --> N([Return course_id and join_code])
    M --> N
```

---

## 4. State Diagrams

### 4.1 Exam Lifecycle States

```mermaid
stateDiagram-v2
    [*] --> Draft : Admin creates exam
    Draft --> Published : Admin publishes exam
    Draft --> Draft : Admin edits questions
    Published --> Archived : Admin archives exam
    Published --> Published : Students take exam
    Archived --> [*] : Exam retired

    state Published {
        [*] --> Active
        Active --> Scheduled : scheduled_at is set
        Scheduled --> Active : Time reached
        Active --> Expired : end_at passed
    }
```

### 4.2 Submission Status States

```mermaid
stateDiagram-v2
    [*] --> InProgress : Student starts exam
    InProgress --> Submitted : Student submits answers
    InProgress --> Cheated : Anti-cheat triggered
    InProgress --> InProgress : Student saves draft answers
    Submitted --> Graded : Auto-grading completes
    Cheated --> Graded : Result with cheating_detected = 1
    Graded --> [*] : Result stored in DB

    state Graded {
        [*] --> ScoreCalculated
        ScoreCalculated --> GradeAssigned
        GradeAssigned --> ResultSaved
        ResultSaved --> [*]
    }
```

### 4.3 Viva Session States

```mermaid
stateDiagram-v2
    [*] --> Active : Admin creates session
    Active --> Active : Students join via Jitsi
    Active --> Active : Q&A rounds continue
    Active --> Ended : Admin clicks End Session
    Active --> Locked : Examiner away > 10 min
    Ended --> [*] : Invitations cleared and notifications sent
    Locked --> [*] : Invitations cleared, session expired notification sent

    state Active {
        [*] --> WaitingForStudents
        WaitingForStudents --> InSession : Student joins
        InSession --> Questioning : Admin sends question
        Questioning --> Answering : Student responds
        Answering --> Grading : Admin grades answer
        Grading --> Questioning : Next question
        Grading --> Finalizing : All questions done
        Finalizing --> ResultSaved : Save transcript and AI report
    }
```

### 4.4 Notification Lifecycle States

```mermaid
stateDiagram-v2
    [*] --> Created : System generates notification
    Created --> Delivered : Stored in DB
    Delivered --> Read : Student views notification
    Delivered --> Expired : Viva session ends
    Read --> [*] : Notification consumed
    Expired --> [*] : Notification dismissed

    state Delivered {
        [*] --> Info : type = info
        [*] --> Warning : type = warning
        [*] --> Urgent : type = urgent (Viva invite)
        [*] --> Success : type = success (Result ready)
    }
```

---

## 5. Frontend Component Architecture

The React frontend (`examai-project/examai/src`) uses a Context-based state management pattern (`useStore.js`) with role-based page routing inside `App.jsx`.

### 5.1 Component Hierarchy

```mermaid
flowchart TD
    App["App.jsx (Router)"]
    Store["useStore.js (Global State)"]
    App --> Store

    App --> Auth["AuthPage.jsx"]
    App --> Sidebar["Sidebar.jsx"]
    App --> Toast["Toast.jsx"]

    subgraph AdminPages["Admin Components"]
        AD["AdminDashboard"]
        CE["CreateExam"]
        ME["ManageExams"]
        CP["CoursesPanel"]
        CA["CourseAnalytics"]
        SP["StudentsPanel"]
        AN["Analytics"]
        NF["Notifications"]
        VR["VivaRoom"]
    end

    subgraph StudentPages["Student Components"]
        SD["StudentDashboard"]
        AE["AvailableExams"]
        EI["ExamInterface"]
        MR["MyResults"]
        RV["ResultView"]
        LB["Leaderboard"]
        PZ["PracticeZone"]
        MC["MyCourses"]
        CProg["CourseProgress"]
        VJ["VivaJoin"]
        VP["VivaPractice"]
        SPr["StudentProfile"]
    end

    subgraph SharedComponents["Shared Components"]
        JM["JitsiMeet.jsx"]
        VV["VivaVideo.jsx"]
        YT["YouTubeResources.jsx"]
        CHP["ChangePassword.jsx"]
    end

    App -->|"role = admin"| AdminPages
    App -->|"role = student"| StudentPages
    VR --> JM
    VJ --> JM
    VR --> VV
```

### 5.2 State Management (useStore.js)

```mermaid
classDiagram
    class StoreProvider {
        +User currentUser
        +Student currentStudent
        +Array exams
        +Array questions
        +Array submissions
        +Array results
        +Array students
        +Array notifications
        +boolean examLocked
        +Array toasts
        +login(email, password)
        +register(name, email, password)
        +logout()
        +loadProfile()
        +loadExams()
        +createExam(data)
        +publishExam(examId)
        +deleteExam(examId)
        +startExam(examId)
        +submitExam(submissionId, answers)
        +loadSubmissions(userId)
        +loadLeaderboard(examId)
        +loadAnalytics()
        +updateProfile(data)
        +addToast(msg, type)
    }

    class APILayer {
        +apiGet(path)
        +apiPost(path, body)
        +apiPut(path, body)
        +apiDelete(path)
    }

    StoreProvider --> APILayer : HTTP calls via fetch
    APILayer --> ExpressServer : JWT in Authorization header
```

### 5.3 Full-Stack Data Flow Sequence

```mermaid
sequenceDiagram
    actor User
    participant React as React App
    participant Store as useStore Context
    participant API as utils/api.js
    participant Express as Express Server
    participant MW as Auth Middleware
    participant Route as Route Handler
    participant DB as MySQL

    User->>React: Interacts with UI
    React->>Store: Calls store method
    Store->>API: apiGet/apiPost/apiPut/apiDelete
    API->>API: Attach JWT from localStorage
    API->>Express: HTTP Request with Bearer token
    Express->>MW: authenticateToken / requireAdmin
    MW->>MW: jwt.verify(token)
    MW->>Route: req.user = decoded payload
    Route->>DB: pool.query(SQL)
    DB-->>Route: Result rows
    Route-->>API: JSON response
    API-->>Store: Parsed data
    Store-->>Store: setState(data)
    Store-->>React: Re-render with new state
    React-->>User: Updated UI
```

---

## Summary

| Diagram Type | Count | Covers |
|---|---|---|
| **Class Diagram** | 1 | All 14 database entities, attributes, methods, and relationships |
| **Sequence Diagrams** | 5 | Login, Exam Submission, Viva Lifecycle, Course Join, Full-Stack Data Flow |
| **Activity Diagrams** | 5 | Auto-Grading, Registration, Viva Flow, Password Reset, Course Creation |
| **State Diagrams** | 4 | Exam States, Submission States, Viva States, Notification States |
| **Component Diagrams** | 2 | Frontend hierarchy (Admin + Student), State Management architecture |
| **Total** | **17** | |
