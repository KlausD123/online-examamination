const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const pool = require('../db');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

// Create viva session
router.post('/', requireAdmin, async (req, res) => {
  try {
    const { title, topic, questions } = req.body;
    const viva_id = uuidv4();
    
    await pool.query(
      'INSERT INTO viva_sessions (viva_id, title, topic, questions, questions_count, created_by) VALUES (?, ?, ?, ?, ?, ?)',
      [viva_id, title, topic, JSON.stringify(questions), questions.length, req.user.user_id]
    );
    
    res.status(201).json({ viva_id, message: 'Viva session created' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get admin's past sessions
router.get('/', requireAdmin, async (req, res) => {
  try {
    const [sessions] = await pool.query('SELECT * FROM viva_sessions WHERE created_by = ? ORDER BY created_at DESC', [req.user.user_id]);
    res.json(sessions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get student's viva results
router.get('/my-results', authenticateToken, async (req, res) => {
  try {
    const [results] = await pool.query(
      'SELECT r.*, s.title, s.topic FROM viva_results r JOIN viva_sessions s ON r.viva_id = s.viva_id WHERE r.student_id = ? ORDER BY r.created_at DESC',
      [req.user.user_id]
    );
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Fetch session (for student join)
router.get('/:viva_id', authenticateToken, async (req, res) => {
  try {
    const [[session]] = await pool.query('SELECT * FROM viva_sessions WHERE viva_id = ?', [req.params.viva_id]);
    if (!session) return res.status(404).json({ error: 'Session not found' });
    res.json(session);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Save AI-graded result
router.post('/:viva_id/result', requireAdmin, async (req, res) => {
  try {
    const { student_id, student_name, total_score, grade, full_transcript, ai_report } = req.body;
    
    await pool.query(
      'INSERT INTO viva_results (viva_id, student_id, student_name, total_score, grade, full_transcript, ai_report) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [req.params.viva_id, student_id || null, student_name || '', total_score, grade, full_transcript, JSON.stringify(ai_report)]
    );
    
    res.status(201).json({ message: 'Result saved successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Send invite
router.post('/invite', requireAdmin, async (req, res) => {
  try {
    const { emails, title, topic, vivaId } = req.body;
    if (!emails || emails.length === 0) return res.status(400).json({ error: 'No emails provided' });
    
    var sentCount = 0;
    
    for (var i = 0; i < emails.length; i++) {
      var emailAddr = emails[i].trim();
      var rows = await pool.query('SELECT user_id FROM users WHERE email = ?', [emailAddr]);
      var user = rows[0][0];
      if (user) {
        var msgTitle = 'Viva Invitation: ' + title;
        var msgBody = 'You have been invited to join a Viva session on ' + topic + '.';
        await pool.query(
          'INSERT INTO notifications (title, message, type, admin_id, recipient_id, viva_room_id) VALUES (?, ?, "urgent", ?, ?, ?)',
          [msgTitle, msgBody, req.user.user_id, user.user_id, vivaId]
        );
        sentCount++;
      }
    }
    
    res.json({ message: 'Invited ' + sentCount + ' students' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;

// Mark session as ended (admin calls this when ending viva — students get kicked)
router.post('/:viva_id/end', requireAdmin, async (req, res) => {
  try {
    await pool.query(
      'UPDATE viva_sessions SET status = "ended", ended_at = NOW() WHERE viva_id = ? AND created_by = ?',
      [req.params.viva_id, req.user.user_id]
    );
    // Notify all students in this session
    await pool.query(
      'INSERT INTO notifications (title, message, type, admin_id, viva_room_id) VALUES (?, ?, ?, ?, ?)',
      ['Viva Session Ended', 'The examiner has ended the viva session. Please check My Results for your grade.', 'info', req.user.user_id, req.params.viva_id]
    );
    res.json({ message: 'Session ended' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Mark session as locked (examiner away timeout)
router.post('/:viva_id/lock', requireAdmin, async (req, res) => {
  try {
    await pool.query(
      'UPDATE viva_sessions SET status = "locked", ended_at = NOW() WHERE viva_id = ? AND created_by = ?',
      [req.params.viva_id, req.user.user_id]
    );
    res.json({ message: 'Session locked' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ── WebRTC signaling: store/retrieve SDP offers and ICE candidates ──
// Admin stores offer → Student reads it and sends answer → Admin reads answer
var signalingStore = {}; // in-memory: { viva_id: { offer, answer, adminCandidates:[], studentCandidates:[] } }

router.post('/:viva_id/signal/offer', authenticateToken, async (req, res) => {
  var id = req.params.viva_id;
  if (!signalingStore[id]) signalingStore[id] = { adminCandidates: [], studentCandidates: [] };
  signalingStore[id].offer = req.body.offer;
  res.json({ ok: true });
});

router.get('/:viva_id/signal/offer', authenticateToken, async (req, res) => {
  var id = req.params.viva_id;
  res.json({ offer: signalingStore[id] ? signalingStore[id].offer : null });
});

router.post('/:viva_id/signal/answer', authenticateToken, async (req, res) => {
  var id = req.params.viva_id;
  if (!signalingStore[id]) signalingStore[id] = { adminCandidates: [], studentCandidates: [] };
  signalingStore[id].answer = req.body.answer;
  res.json({ ok: true });
});

router.get('/:viva_id/signal/answer', authenticateToken, async (req, res) => {
  var id = req.params.viva_id;
  res.json({ answer: signalingStore[id] ? signalingStore[id].answer : null });
});

router.post('/:viva_id/signal/candidate', authenticateToken, async (req, res) => {
  var id = req.params.viva_id;
  if (!signalingStore[id]) signalingStore[id] = { adminCandidates: [], studentCandidates: [] };
  var role = req.body.role; // 'admin' or 'student'
  var candidate = req.body.candidate;
  if (role === 'admin') signalingStore[id].adminCandidates.push(candidate);
  else signalingStore[id].studentCandidates.push(candidate);
  res.json({ ok: true });
});

router.get('/:viva_id/signal/candidates/:role', authenticateToken, async (req, res) => {
  var id   = req.params.viva_id;
  var role = req.params.role; // 'admin' or 'student'
  var data = signalingStore[id] || { adminCandidates: [], studentCandidates: [] };
  res.json({ candidates: role === 'admin' ? data.adminCandidates : data.studentCandidates });
});
